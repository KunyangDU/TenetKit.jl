struct NoAlgorithm <: AbstractAlgorithm NoAlgorithm() = new() end
# struct noalgorithm <: NoAlgorithm noalgorithm() = new() end


struct Krylovalgo <: SolverAlgo
    Alg::KrylovKit.KrylovAlgorithm
    Krylovalgo(Alg::KrylovKit.KrylovAlgorithm) = new(Alg)
end

struct SETTNalgo{Sch} <: AbstractAlgorithm where {Sch}
    scheme::AbstractScheme
    alg::AbstractAlgorithm
    trunc::TruncationScheme
    N::Int64
    tol::Number
    function SETTNalgo(scheme::AbstractScheme, alg::AbstractAlgorithm, trunc::TruncationScheme, N::Int64, tol::Number)
        new{typeof(scheme)}(scheme,alg,trunc,N,tol)
    end
end

struct DMRGalgo{Sch,Alg} <: AbstractAlgorithm where {Sch,Alg}
    scheme::AbstractScheme
    alg::AbstractAlgorithm
    trunc::TruncationScheme
    N::Int64
    tol::Number
    solver::SolverAlgo
    function DMRGalgo(scheme::AbstractScheme, alg::AbstractAlgorithm, trunc::TruncationScheme, N::Int64, tol::Number, solver::SolverAlgo)
        new{typeof(scheme),typeof(alg)}(scheme,alg,trunc,N,tol,solver)
    end
end

mutable struct TDVPalgo{Sch,Alg} <: AbstractAlgorithm where {Sch,Alg}
    scheme::AbstractScheme
    alg::AbstractAlgorithm
    trunc::TruncationScheme
    τ::Number 
    tol::Number
    solver::SolverAlgo
    function TDVPalgo(scheme::AbstractScheme, alg::AbstractAlgorithm, trunc::TruncationScheme, τ::Number, tol::Number, solver::SolverAlgo)
        new{typeof(scheme),typeof(alg)}(scheme,alg,trunc,τ,tol,solver)
    end
end

struct CBEalgo{Sch,Struc,Tar} <: AbstractAlgorithm where {Sch,Struc,Tar}
    scheme::AbstractScheme
    structure::AbstractStructure
    target::Int64
    D::Int64 
    # ϵ::Number
    CBEalgo(alg::CBEalgo, scheme::AbstractScheme) = new{typeof(scheme), typeof(alg.structure), alg.target}(scheme, alg.structure, alg.target, alg.D)
    CBEalgo(scheme::AbstractScheme,structure::AbstractStructure,target::Int64,D::Int64) = new{typeof(scheme),typeof(structure),target}(scheme,structure,target,D)
    CBEalgo(alg::CBEalgo,structure::AbstractStructure) = new{typeof(alg.scheme),typeof(structure),alg.target}(alg.scheme,structure,alg.target,alg.D)
    CBEalgo(alg::CBEalgo,structure::AbstractStructure,target::Int64) = new{typeof(alg.scheme), typeof(structure), target}(alg.scheme, structure, target, alg.D)
end

struct Algebraalgo{Sch,Alg} <: AbstractAlgorithm where {Sch,Alg}
    scheme::AbstractScheme
    alg::AbstractAlgorithm
    trunc::TruncationScheme
    N::Int64
    tol::Number
    function Algebraalgo(scheme::AbstractScheme, alg::AbstractAlgorithm, trunc::TruncationScheme,N::Int64, tol::Number)
        new{typeof(scheme),typeof(alg)}(scheme,alg,trunc,N,tol)
    end
end

#= ========================= =#

# function merge!(A::Krylovalgo,B::Krylovalgo)
#     @assert A.A == B.A "KrylovAlgorithm mistmatch" 
# end
# function merge(A::Krylovalgo,B::Krylovalgo)
#     @assert A.A == B.A "KrylovAlgorithm mistmatch" 
#     return A
# end



